#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

SDL_Window* displayWindow;
bool gameIsRunning = true;
bool won = false;
bool lost = false;

ShaderProgram program;
glm::mat4 viewMatrix, modelMatrixShip, modelMatrixMoon, modelMatrixText, projectionMatrix;
glm::vec3 position = glm::vec3(0, 0, 0);
glm::vec3 velocity = glm::vec3(0, 0, 0);
glm::vec3 acceleration = glm::vec3(0, -0.0981, 0);
GLuint TextureIDship;
GLuint TextureIDmoon;
GLuint TextureIDfont;

GLuint LoadTexture(const char* filePath) {
    int w, h, n;
    unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);
    if (image == NULL) {
        std::cout << "Unable to load image. Make sure the path is correct\n";
        assert(false);
    }
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    stbi_image_free(image);
    return textureID;
}

void Initialize() {
    SDL_Init(SDL_INIT_VIDEO);
    displayWindow = SDL_CreateWindow("Lunar Lander!", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);
#ifdef _WINDOWS
    glewInit();
#endif
    glViewport(0, 0, 640, 480);
    program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
    viewMatrix = glm::mat4(1.0f);
    modelMatrixShip = glm::mat4(1.0f);
    modelMatrixMoon = glm::mat4(1.0f);
    modelMatrixText = glm::mat4(1.0f);
    projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);
    program.SetProjectionMatrix(projectionMatrix);
    program.SetViewMatrix(viewMatrix);
    glUseProgram(program.programID);
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    TextureIDship = LoadTexture("ship.png");
    TextureIDmoon = LoadTexture("moon.jpg");
    TextureIDfont = LoadTexture("font1.png");
}

void Text(GLuint textureID, int index, int order) {
    float u = (float)((index % 16) / 16);
    float v = (float)((index / 16) / 16);
    float width = 1 / 16;
    float height = 1 / 16;
    order = order - 4;
    program.SetModelMatrix(modelMatrixText);
    float texCoords[] = { u, v + height, u + width, v + height, u + width, v, u, v + height, u + width, v, u, v };
    float vertices[] = { -0.5 + order, -0.5, 0.5 + order, -0.5, 0.5 + order, 0.5, -0.5 + order, -0.5, 0.5 + order, 0.5, -0.5 + order, 0.5 };
    glBindTexture(GL_TEXTURE_2D, textureID);
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
    glEnableVertexAttribArray(program.positionAttribute);
    glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
    glEnableVertexAttribArray(program.texCoordAttribute);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glDisableVertexAttribArray(program.positionAttribute);
    glDisableVertexAttribArray(program.texCoordAttribute);
}

void Failure() { 
    Text(TextureIDfont, 'F', 1);
    Text(TextureIDfont, 'A', 2);
    Text(TextureIDfont, 'I', 3);
    Text(TextureIDfont, 'L', 4);
    Text(TextureIDfont, 'U', 5);
    Text(TextureIDfont, 'R', 6);
    Text(TextureIDfont, 'E', 7);
}

void Success() { 
    Text(TextureIDfont, 'S', 1);
    Text(TextureIDfont, 'U', 2);
    Text(TextureIDfont, 'C', 3);
    Text(TextureIDfont, 'C', 4);
    Text(TextureIDfont, 'E', 5);
    Text(TextureIDfont, 'S', 6);
    Text(TextureIDfont, 'S', 7);
}

void ProcessInput() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
            gameIsRunning = false;
        }
    }
    const Uint8* keys = SDL_GetKeyboardState(NULL);
    if (keys[SDL_SCANCODE_LEFT])
    {
        acceleration.x = -1;
    }
    else if (keys[SDL_SCANCODE_RIGHT])
    {
        acceleration.x = 1;
    }
    else
    {
        acceleration.x = 0;
    }
}

#define FIXED_TIMESTEP 0.0166666f;
float lastTicks = 0;
float accumulator = 0.0f;
float endtime = 0;

void Update() { 
    float ticks = (float)SDL_GetTicks() / 1000.0f;
    float deltaTime = ticks - lastTicks;
    lastTicks = ticks;
    /*
    deltaTime += accumulator;
    if (deltaTime < FIXED_TIMESTEP)
    {
        accumulator = deltaTime;
        return;
    }
    while (deltaTime >= FIXED_TIMESTEP)
    {
        Update(FIXED_TIMESTEP);
        deltaTime -= FIXED_TIMESTEP;
    }
    accumulator = deltaTime;
    */
    if (!won && !lost)
    {
        velocity += acceleration * deltaTime;
        position += velocity * deltaTime;
        modelMatrixShip = glm::mat4(1.0f);
        modelMatrixShip = glm::translate(modelMatrixShip, position);
    }
    if (position.y <= -6 && position.x >= -0.5 && position.x <= 0.5)
    {
        won = true;
    }
    else if (position.x <= -4 || position.x >= 4 || position.y <= -6)
    {
        lost = true;
    }
}

void RenderMoon(float vertices[], float texCoords[])
{
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
    glEnableVertexAttribArray(program.positionAttribute);
    glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
    glEnableVertexAttribArray(program.texCoordAttribute);
    glBindTexture(GL_TEXTURE_2D, TextureIDmoon);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glDisableVertexAttribArray(program.positionAttribute);
    glDisableVertexAttribArray(program.texCoordAttribute);
}

void Render() {
    glClear(GL_COLOR_BUFFER_BIT);

    if (won) { Success(); }
    if (lost) { Failure(); }

    program.SetModelMatrix(modelMatrixShip);
    float vertices[] = { -0.5, 2.75, 0.5, 2.75, 0.5, 3.75, -0.5, 2.75, 0.5, 3.75, -0.5, 3.75 };
    float texCoords[] = { 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0 };
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
    glEnableVertexAttribArray(program.positionAttribute);
    glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
    glEnableVertexAttribArray(program.texCoordAttribute);
    glBindTexture(GL_TEXTURE_2D, TextureIDship);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glDisableVertexAttribArray(program.positionAttribute);
    glDisableVertexAttribArray(program.texCoordAttribute);

    program.SetModelMatrix(modelMatrixMoon);
    float vertices0[] = { -1, -3.75, 1, -3.75, 1, -3.25, -1, -3.75, 1, -3.25, -1, -3.25 };
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices0);
    glEnableVertexAttribArray(program.positionAttribute);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glDisableVertexAttribArray(program.positionAttribute);

    float vertices1[] = { -5, 3.25, -4.5, 3.25, -4.5, 3.75, -5, 3.25, -4.5, 3.75, -5, 3.75 };
    float texCoords1[] = { 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0 };
    //float texCoords1[] = { 0, 14, 1, 14, 1, 0, 0, 14, 1, 0, 0, 0 };
    RenderMoon(vertices1, texCoords1);
    float vertices2[] = { 4.5, 3.25, 5, 3.25, 5, 3.75, 4.5, 3.25, 5, 3.75, 4.5, 3.75 };
    float texCoords2[] = { 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0 };
    //float texCoords2[] = { 0, 14, 1, 14, 1, 0, 0, 14, 1, 0, 0, 0 };
    RenderMoon(vertices2, texCoords2);
    float vertices3[] = { -5, -3.75, -4.5, -3.75, -4.5, -3.25, -5, -3.75, -4.5, -3.25, -5, -3.25 };
    float texCoords3[] = { 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0 };
    //float texCoords3[] = { 0, 1, 8, 1, 8, 0, 0, 1, 8, 0, 0, 0 };
    RenderMoon(vertices3, texCoords3);
    float vertices4[] = { 1, -3.75, 1.5, -3.75, 1.5, -3.25, 1, -3.75, 1.5, -3.25, 1, -3.25 };
    float texCoords4[] = { 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0 };
    //float texCoords3[] = { 0, 1, 8, 1, 8, 0, 0, 1, 8, 0, 0, 0 };
    RenderMoon(vertices4, texCoords4);

    SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
    SDL_Quit();
}

int main(int argc, char* argv[]) {
    Initialize();

    while (gameIsRunning) {
        ProcessInput();
        Update();
        Render();
    }
    Shutdown();
    return 0;
}


